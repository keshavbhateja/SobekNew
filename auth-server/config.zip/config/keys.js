module.exports = {
  googleClientID: '838324827519-1iqqn12lt5m60picojgvs137ml95cv46.apps.googleusercontent.com',
  googleClientSecret: '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',
  mongoURI: 'mongodb+srv://musoliman14:wZ98qneVk1yMd8YL@sobek.yibtuka.mongodb.net/test',
  cookieKey: 'asasaasasasasas'
};